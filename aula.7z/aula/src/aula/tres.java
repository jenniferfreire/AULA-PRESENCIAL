package aula;

public class tres {
	public static void main (String args[]) 
	{
		//declara��o e inicio de variaveis
		int x =10;
		int y =3;
		//v�rias opera��es com as variaveis
		System.out.println("X = "+ x);
		System.out.println("Y = "+ y);
		System.out.println("-X = "+ (-x));
		System.out.println("X/Y = " + (x/y));
		System.out.println("O resto de X por Y = "+(x%y) );
		System.out.println("X + 1 = "+(++x));
	}
}
