package aula;

public class oito {
	public static void main (String args[]) 
	{
		double C=2.43;		
		double formulaF=((C*9/5)+32);
		double formulaK=(C+273.15);
		{
		System.out.println("Graus Celius (�C): "+C+" �C");
		System.out.println("Graus em Fahrenheit (�F): "+formulaF+" �F");
		System.out.println("Graus em Kelvin (�K): "+formulaK+" �K");
		}
	}
}