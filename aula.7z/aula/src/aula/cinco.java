package aula;

public class cinco {
	public static void main (String args[]) 
	{
		int idadeatual =22;
		System.out.println("Idade atual: "+ idadeatual);
		System.out.println("Idade ano que vem: "+ (++idadeatual));
	}
}