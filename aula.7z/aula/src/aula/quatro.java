package aula;

public class quatro {
	public static void main (String args[]) 
	{
		System.out.println("Minha aplica��o");
	}
}
