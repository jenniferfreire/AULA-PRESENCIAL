package aula;

public class um {
public static void main (String args[])
{
	System.out.println("Inicio do aprendizado");
	System.out.println("Bem-vindo ao Java!");
}
}
