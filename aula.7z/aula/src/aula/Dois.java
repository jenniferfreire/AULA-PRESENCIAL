package aula;

public class Dois {
	public static void main (String args[]) 
	{
		int x =10, y =20;
		double dolar = 5.61;
		System.out.println("X:"+" "+x);
		System.out.println(y);
		System.out.println("O valor do D�lar �: R$"+""+dolar);
	}
}
