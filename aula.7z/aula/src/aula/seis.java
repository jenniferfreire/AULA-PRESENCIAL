package aula;

public class seis {
	public static void main (String args[]) 
	{
		int idade =15;
			boolean AmigoDoDono = true;
			if (idade >=18 && AmigoDoDono == false) {
					System.out.println("N�o pode entrar!");
			}
			else {
				System.out.println("Pode entrar!");
			}
	}
}