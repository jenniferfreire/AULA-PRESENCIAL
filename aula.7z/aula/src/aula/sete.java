package aula;

public class sete {
	public static void main (String args[]) 
	{
		int nu=15;
		while (nu <= 100) {
			System.out.println(nu);
			nu=nu+1;
		}
	}
}