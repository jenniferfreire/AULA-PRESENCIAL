drop database if exists contasbanco;
create database contasbanco;
use contasbanco;
create table cliente (
agencia integer,
conta integer,
cpf varchar(14),
nome varchar(20),
nascimento date,
endereco varchar(30),
telefone varchar(15),
saldo float,
senha varchar(10),
primary key(agencia,conta)
);
create table contacorrente (
numero_doc integer primary key,
agencia integer,
conta integer,
valor float,
tipo enum('1','2','3'),
data_ocorrencia datetime default now(),
constraint fk_cc foreign key (agencia, conta) references cliente (agencia, conta)
);
insert into cliente value (100, 34567, '123.456.788-92','Valdir de Almeida','1975/03/28','Rua Assaí 234','(11)99123-4564',0,'abc@1234');
insert into cliente value (100, 34568,'123.456.788-93', 'Laura de Assis','1974/04/27','Rua Amorin 235','(11)96234-7692',0,'dfg@5678');
insert into cliente value (100, 34569,'123.456.788-94','Bruno da Silva','1973/05/26','Av. Deputado Emilio 236','(11)96667-4523',0,'hij@1234');
insert into cliente value (100, 34570,'123.456.788-95','Vanessa Arruda','1972/06/25','Av. Emilio Castro 267','(11)97788-2321',0,'klm@5978');
select * from cliente;